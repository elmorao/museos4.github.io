var story = {
 "docName": "wireframes",
 "docPath": "P_P_P",
 "docVersion": 100000001,
 "ownerName": "",
 "ownerEmail": "",
 "authorName": "V_V_N",
 "authorEmail": "V_V_E",
 "fileType": "jpg",
 "disableInteractions": false,
 "highlightHotspot": true,
 "highlightAllHotspots": true,
 "hideGallery": false,
 "galleryPageColorsEnabled": true,
 "galleryDecorNodesEnabled": true,
 "zoomEnabled": true,
 "cloud": false,
 "title": "wireframes",
 "layersExist": true,
 "pages": [
  {
   "id": "129:26",
   "groupID": "0:1",
   "transAnimType": 0,
   "title": "Frame 47",
   "image": "frame-47.jpg",
   "index": 0,
   "width": 673,
   "height": 403,
   "x": -1475,
   "y": 1670,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Boton",
     "rect": {
      "x": 191,
      "y": 162,
      "width": 291,
      "height": 80
     },
     "index": 0,
     "page": 1
    }
   ],
   "overlayPinPage": 6,
   "overlayCloseOnClickOutside": false,
   "layout": null
  },
  {
   "id": "129:30",
   "groupID": "0:1",
   "transAnimType": 0,
   "title": "Frame 48",
   "image": "frame-48.jpg",
   "index": 1,
   "width": 673,
   "height": 403,
   "x": -762,
   "y": 1670,
   "isFrame": true,
   "type": "regular",
   "fixedPanels": [],
   "links": [
    {
     "name": "Boton",
     "rect": {
      "x": 191,
      "y": 162,
      "width": 291,
      "height": 80
     },
     "index": 1,
     "page": 0
    }
   ],
   "overlayPinPage": 6,
   "overlayCloseOnClickOutside": false,
   "layout": null
  }
 ],
 "groups": [
  {
   "id": "0:1",
   "name": "Page 1",
   "backColor": "#1E1E1E"
  }
 ],
 "totalImages": 2
}